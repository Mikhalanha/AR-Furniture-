# MebelAR

An Android AR application for visualizing furniture items in the real world built with Unity.

## Overview

The project explores Android AR technologies and development with Unity.

- **Subject**: 3D Technologies and Virtual Reality
- **Semester**: 8
- **Year**: 2024

## Features

- Automatic surface detection (horizontal and vertical)
- Place on the ground and on the walls
- 15 various furniture items
- Gesture controls
  - Moving items
  - Scaling items
  - Rotating items
- Remove placed items
- In-app hints

## Screenshots

### Item menu

![Item menu](docs/images/item-menu.jpg)

### Room with furniture

![Room with furniture](docs/images/room-with-furniture.jpg)

## Tech Stack

- Unity
- AR Foundation

## Running locally

- Open project in Unity

OR

1. Go to Releases and download `MebelAR-v1.0.0-Release.apk`
2. Transfer the file to an Android device and install the apk